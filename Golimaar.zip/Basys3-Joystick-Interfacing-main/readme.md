# Non-PMOD Joystck Driver for Basys3

- Please refer to the pdf to get started.
- The project can be opened in vivado and can be used as an input module for integration.

Reference:
https://github.com/Digilent/Basys3
